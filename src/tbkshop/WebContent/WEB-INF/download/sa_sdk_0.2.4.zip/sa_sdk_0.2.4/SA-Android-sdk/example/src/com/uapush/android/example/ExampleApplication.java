package com.uapush.android.example;

import android.app.Application;
import android.util.Log;

import cn.com.smiletomato.api.UAInterface;

/**
 * For developer startup UA Push SDK
 * 
 */
public class ExampleApplication extends Application {
    private static final String TAG = "ExampleApplication";

    @Override
    public void onCreate() {
        Log.d(TAG, "onCreate");
        super.onCreate();

        /**
         * Optional: Only for show log
         * 
         * It will have some logs if you add this line,
		 * please remove it when you release you app.
         */
        UAInterface.setDebugMode(true);
        
        /**
         * Required
         * 
         * Init the smiletomato SDK
         */
        UAInterface.initPush(this.getApplicationContext());
  
    }
}
