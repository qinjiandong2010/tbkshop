package com.uapush.android.example;


import android.os.Bundle;
import android.view.KeyEvent;
import cn.com.smiletomato.api.InstrumentedActivity;

public class MainActivity extends InstrumentedActivity {

    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
    	if(keyCode == KeyEvent.KEYCODE_HOME||keyCode == KeyEvent.KEYCODE_BACK){
    		finish();
    		return true;
    	}else{
    		return super.onKeyDown(keyCode, event);
    	}
	}

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    
    
}
